from django.db import models
from plugin_skeleton.models import BaseItemManager, BaseOrderManager, BaseItem, BaseOrder, BaseOrderItem
# Create your models here.

class ItemManager(BaseItemManager):
    def __init__(self, model=None):
        super().__init__()
        self.model = model
    
    pass

class Item(BaseItem):
    objects = ItemManager()

    class Meta:
        abstract = False

    pass

class OrderManager(BaseOrderManager):
    def __init__(self, model=None):
        super().__init__()
        self.model = model

    pass

class Order(BaseOrder):
    objects = OrderManager()
    
    class Meta:
        abstract = False

    def add_item(self, item: BaseItem, quantity: int):
        OrderItem.objects.create(item=item, order=self, quantity=quantity)

    pass

class OrderItem(BaseOrderItem):
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    order = models.ForeignKey(Order, on_delete=models.CASCADE)

    
    class Meta:
        abstract = False

    pass